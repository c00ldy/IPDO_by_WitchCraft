import React, { useState, useEffect } from "react";
import Features from "../Features/Features";

const Main = () => {
  const [ipAddress, setIpAddress] = useState("");
  const [ipDetails, setIpDetails] = useState(null);
  const [lookupTriggered, setLookupTriggered] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    const fetchData = async () => {
      if (!ipAddress) {
        setIpDetails(null);
        return;
      }

      try {
        const response = await fetch(
          `http://localhost:3000/api/shodan/${ipAddress}`
        );
        const data = await response.json();

        if (response.ok) {
          setIpDetails(data);
        } else {
          alert(data.error || "No details found for the entered IP address.");
          setIpDetails(null);
        }
      } catch (error) {
        console.error("Error fetching IP details:", error.message);
        alert("An error occurred while fetching the IP details.");
        setIpDetails(null);
      }
    };

    if (lookupTriggered) {
      fetchData();
      setLookupTriggered(false);
    }
  }, [lookupTriggered, ipAddress]);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!ipAddress.trim()) {
      setError("Please enter an IP address.");
      return;
    }

    setError("");
    setIpAddress(ipAddress.trim());
    setLookupTriggered(true);
  };

  return (
    <div className="flex flex-col items-center min-h-screen bg-[#010b18] text-[#a1caff]">
      <div className="space-y-2 text-center">
        <h1 className="text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl lg:text-6xl mt-7">
          Unveil the Secrets of IP Addresses
        </h1>
        <p className="mx-auto max-w-[700px] text-lg md:text-xl">
          Discover vulnerabilities, open ports, and crucial information about
          any IP address. Enhance your threat intelligence with WitchCraft.
        </p>
      </div>

      <form onSubmit={handleSubmit} className="flex space-x-4 mb-8 mt-7">
        <input
          type="text"
          value={ipAddress}
          onChange={(e) => setIpAddress(e.target.value)}
          placeholder="Enter your IP address"
          className="px-4 py-2 border border-blue-500 rounded bg-[#010b18] text-[#a1caff] focus:outline-none"
        />
        <button
          type="submit"
          className="px-6 py-2 bg-blue-500 text-white rounded hover:bg-blue-600"
        >
          Look Up
        </button>
      </form>

      {error && <p className="text-red-500">{error}</p>}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 w-full max-w-6xl">
        {ipDetails && (
          <>
            <div className="bg-[#0d1b2a] p-6 rounded shadow-lg">
              <h2 className="text-xl font-bold mb-4">Basic Information</h2>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <p className="font-semibold">IP Address:</p>
                  <p>{ipDetails.Ip}</p>
                </div>
                <div className="flex justify-between">
                  <p className="font-semibold">ISP:</p>
                  <p>{ipDetails.isp}</p>
                </div>
                <div className="flex justify-between">
                  <p className="font-semibold">Organization:</p>
                  <p>{ipDetails.Organization}</p>
                </div>
                <div className="flex justify-between">
                  <p className="font-semibold">Domains:</p>
                  <p>{ipDetails.domains}</p>
                </div>
                <div className="flex justify-between">
                  <p className="font-semibold">ASN:</p>
                  <p>{ipDetails.ASN}</p>
                </div>
              </div>
            </div>

            <div className="bg-[#0d1b2a] p-6 rounded shadow-lg">
              <h2 className="text-xl font-bold mb-4">Location</h2>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <p className="font-semibold">City:</p>
                  <p>{ipDetails.city}</p>
                </div>
                <div className="flex justify-between">
                  <p className="font-semibold">Region:</p>
                  <p>{ipDetails.region}</p>
                </div>
                <div className="flex justify-between">
                  <p className="font-semibold">Country Name:</p>
                  <p>{ipDetails.country_name}</p>
                </div>
                <div className="flex justify-between">
                  <p className="font-semibold">Longitude:</p>
                  <p>{ipDetails.longitude}</p>
                </div>
                <div className="flex justify-between">
                  <p className="font-semibold">Latitude:</p>
                  <p>{ipDetails.latitude}</p>
                </div>
              </div>
            </div>

            <div className="bg-[#0d1b2a] p-6 rounded shadow-lg">
              <h2 className="text-xl font-bold mb-4">Cloud Information</h2>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <p className="font-semibold">Region:</p>
                  <p>{ipDetails.region}</p>
                </div>
                <div className="flex justify-between">
                  <p className="font-semibold">Service:</p>
                  <p>{ipDetails.service}</p>
                </div>
                <div className="flex justify-between">
                  <p className="font-semibold">Provider:</p>
                  <p>{ipDetails.provider}</p>
                </div>
              </div>
            </div>

            <div className="bg-[#0d1b2a] p-6 rounded shadow-lg col-span-1 md:col-span-2 lg:col-span-3">
              <h2 className="text-xl font-bold mb-4">Open Ports</h2>
              <div className="space-y-2">
                <p>{ipDetails.openPorts.join(", ")}</p>
              </div>
            </div>

            <div className="bg-[#0d1b2a] p-6 rounded shadow-lg col-span-2 md:col-span-2 lg:col-span-3 mb-10">
              <h2 className="text-xl font-bold mb-4">
                Passive Vulnerabilities
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {ipDetails.PassiveVulnerability &&
                ipDetails.PassiveVulnerability.length > 0 ? (
                  ipDetails.PassiveVulnerability.map((vulnerability, index) => (
                    <div key={index} className="p-2">
                      <p className="text-[#a1caff]">{vulnerability}</p>
                    </div>
                  ))
                ) : (
                  <p className="text-gray-400">
                    No passive vulnerabilities found.
                  </p>
                )}
              </div>
            </div>
          </>
        )}
      </div>

      {!ipDetails && <Features />}
    </div>
  );
};

export default Main;
