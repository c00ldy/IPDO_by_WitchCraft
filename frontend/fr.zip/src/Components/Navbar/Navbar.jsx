import React from "react";
import { assets } from "../../assets/assets";
import { Link } from "react-router-dom";

const Navbar = () => {
  return (
    <div>
      <header className="w-full bg-[#010b18] px-4 lg:px-6 h-14 flex items-center justify-between border-b border-blue-500">
        {/* Left Section: Logo */}
        <div className="flex items-center">
          <Link to='/'><img src={assets.logo} alt="Logo" className="w-40" /></Link>
        </div>

        {/* Center Section: Navigation Links */}
        <nav className="absolute left-1/2 transform -translate-x-1/2 flex gap-4 sm:gap-6 text-[#a1caff] text-sm sm:text-base">
          <Link to= '/home' >
            <p className="hover:underline">
              Home
            </p>
          </Link>
          <Link to= '/about'>
            <p className="hover:underline">
              About
            </p>
          </Link>
          <Link to='/docs'>
            <p className="hover:underline">
              Docs
            </p>
          </Link>
          <Link to='/contact'>
            <p className="hover:underline">
              Contact
            </p>
          </Link>
        </nav>

        {/* Right Section: Sign Up Button */}
        <div className="ml-auto">
          <a
            href="#"
            className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 transition-colors text-sm sm:text-base"
          >
            Sign Up
          </a>
        </div>
      </header>
    </div>
  );
};

export default Navbar;
