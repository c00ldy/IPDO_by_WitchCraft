import React from 'react'
import Main from '../Components/Main/Main'
import Features from '../Components/Features/Features'

const Home = () => {
  return (
    <div  >
      <Main/>
      {/* <Features/> */}
    </div>
  )
}

export default Home
