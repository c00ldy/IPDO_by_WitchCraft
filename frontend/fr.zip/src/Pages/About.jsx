import React from "react";
import { assets } from "../assets/assets";

const About = () => {
  return (
    <div className="bg-[#010b18] text-[#a1caff] min-h-screen flex flex-col items-center p-6">
      <h1 className="text-3xl font-bold mb-4">About WitchCraft</h1>
      
      <div className="flex items-center justify-center mb-6">
        
        <p className="text-lg text-center max-w-2xl">
          WitchCraft is a cutting-edge platform for IP address intelligence and threat assessment. Our team of cybersecurity experts and data scientists have developed advanced algorithms to provide you with comprehensive insights about any IP address.
        </p>
      </div>
      
      <h2 className="text-2xl font-bold mb-4">Our Mission</h2>
      <p className="mb-6 text-lg text-center max-w-2xl">
        At WitchCraft, our mission extends beyond merely displaying a public IP address in real time. We empower our users with a comprehensive suite of tools designed to effectively manage, monitor, modify, and obscure their IP addresses.
      </p>

      <p className="mb-6 text-lg text-center max-w-2xl">
        In today’s digital landscape, where privacy and security are paramount, we recognize the need for complete control over one’s online presence. Our goal is to equip individuals and organizations with the insights they need to navigate the complexities of IP address management.
      </p>

      <p className="mb-6 text-lg text-center max-w-2xl">
        We are committed to providing valuable resources that not only inform our users but also enhance their ability to safeguard their digital identities. Our innovative tracking tools enable real-time monitoring of IP changes, and our guidance on securely altering or concealing an IP address ensures that users have support at every step of the way.
      </p>

      <p className="mb-6 text-lg text-center max-w-2xl">
        At the core of our mission lies a dedication to fostering a safer and more private internet experience for everyone. We believe that informed users are empowered users, and we aim to cultivate an environment where individuals can confidently take charge of their online interactions. By continuously developing advanced solutions and sharing insightful knowledge, we aspire to make managing IP addresses accessible, straightforward, and efficient for all.
      </p>

      <h2 className="text-2xl font-bold mb-4">Our Team</h2>
      <ul className="list-disc list-inside mb-6 max-w-2xl">
        <li>Dhruval Mevada - Chief Security Officer</li>
        <li>Kunjan Herma - Lead Data Scientist</li>
        <li>Himanshu Makwana - Senior Software Engineer</li>
        <li>Krunal Vaishnav - Threat Intelligence Analyst</li>
      </ul>
      
      <p className="text-center max-w-2xl mb-6">
        Together, we're committed to enhancing global cybersecurity by providing actionable intelligence and empowering organizations to protect their digital assets.
      </p>
      
      <p className="text-lg text-center max-w-2xl">
        Join us on our mission to create a safer online world, one IP address at a time.
      </p>
    </div>
  );
};

export default About;
