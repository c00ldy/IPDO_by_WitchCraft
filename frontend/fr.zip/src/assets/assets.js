import logo from './logo.png';
import about from './about.jpg';

export const assets ={
    logo,
    about
}